-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.21-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for db_sql_exam
CREATE DATABASE IF NOT EXISTS `db_sql_exam` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `db_sql_exam`;

-- Dumping structure for table db_sql_exam.attributes_types
CREATE TABLE IF NOT EXISTS `attributes_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(50) NOT NULL,
  `description` char(50) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table db_sql_exam.attributes_types: ~16 rows (approximately)
/*!40000 ALTER TABLE `attributes_types` DISABLE KEYS */;
INSERT IGNORE INTO `attributes_types` (`id`, `code`, `description`, `created`, `updated`) VALUES
	(1, 'fname', 'First Name', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(2, 'lname', 'Last Name', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(3, 'student_id', 'Student ID', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(4, 'school_id', 'School ID', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(5, 'address', 'Address', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(6, 'gender', 'Gender', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(7, 'age', 'Age', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(8, 'student_level', 'Student Level', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(9, 'section', 'Section', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(10, 'phone_number', 'Phone Number', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(11, 'teacher_id', 'Teacher ID', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(12, 'religion', 'Religion', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(13, 'salary', 'Salary', '2021-11-29 05:08:17', '2021-11-29 05:08:17'),
	(14, 'school_name', 'School Name', '2021-11-29 05:12:44', '2021-11-29 05:12:44'),
	(15, 'birthday', 'Birthday', '2021-11-29 05:12:44', '2021-11-29 05:12:44'),
	(16, 'email', 'Email', '2021-11-29 05:13:11', '2021-11-29 05:13:11');
/*!40000 ALTER TABLE `attributes_types` ENABLE KEYS */;

-- Dumping structure for table db_sql_exam.entities_details
CREATE TABLE IF NOT EXISTS `entities_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_main_id` int(11) NOT NULL,
  `attributes_types_id` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_main_id` (`entities_main_id`,`attributes_types_id`),
  KEY `attributes_types_id` (`attributes_types_id`),
  CONSTRAINT `entities_details_ibfk_2` FOREIGN KEY (`attributes_types_id`) REFERENCES `attributes_types` (`id`),
  CONSTRAINT `entities_details_ibfk_3` FOREIGN KEY (`entities_main_id`) REFERENCES `entities_main` (`parent_entities_main_id`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table db_sql_exam.entities_details: ~149 rows (approximately)
/*!40000 ALTER TABLE `entities_details` DISABLE KEYS */;
INSERT IGNORE INTO `entities_details` (`id`, `entities_main_id`, `attributes_types_id`, `value`, `created`, `updated`) VALUES
	(36, 1, 1, 'Soc', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(37, 1, 2, 'Cunanan', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(38, 1, 7, '28', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(39, 1, 6, 'Female', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(40, 1, 15, 'July 5, 1992', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(41, 1, 16, 'emailsoc@gmail.com', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(42, 1, 5, 'Clark City any', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(43, 1, 13, '50,000', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(44, 3, 3, 'Student-001', '2021-11-29 07:26:42', '2021-11-29 07:26:42'),
	(45, 3, 1, 'Dinard', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(46, 3, 2, 'Nicosia', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(47, 3, 8, 'First Year', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(48, 3, 9, '1B', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(49, 3, 5, 'Tarlac City, Tarlac San Vicente', '2021-11-29 08:02:38', '2021-11-29 08:02:38'),
	(50, 3, 6, 'Male', '2021-11-29 08:04:07', '2021-11-29 08:04:07'),
	(51, 4, 1, 'Joana', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(52, 4, 2, 'Capinpin', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(53, 4, 5, 'Tarlac City', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(54, 4, 6, 'Female', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(55, 4, 9, '1B', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(56, 5, 1, 'Jay', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(57, 5, 2, 'Cap', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(58, 5, 5, 'Tarlac City', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(59, 5, 6, 'Male', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(60, 5, 9, '1B', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(61, 6, 1, 'Jayvee', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(62, 6, 2, 'Capssss', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(63, 6, 5, 'Tarlac City vicente', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(64, 6, 6, 'Male', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(65, 6, 9, '1B', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(71, 7, 1, 'Joan', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(72, 7, 2, 'Capin', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(73, 7, 5, 'Tarlac City', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(74, 7, 6, 'Female', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(75, 7, 9, '1B', '2021-11-29 08:10:00', '2021-11-29 08:10:00'),
	(76, 6, 1, 'Nico', '2021-11-29 10:08:52', '2021-11-29 10:08:52'),
	(79, 8, 1, 'Alfredo', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(80, 8, 2, 'Craws', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(81, 8, 7, '31', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(82, 8, 6, 'Male', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(83, 8, 15, 'March 15, 1991', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(84, 8, 16, 'emailalfredo@gmail.com', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(85, 8, 5, 'Tarlac City, Tibag', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(86, 8, 13, '25,000', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(87, 9, 1, 'Jamill', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(88, 9, 2, 'Sandford', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(89, 9, 7, '25', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(90, 9, 6, 'Male', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(91, 9, 15, 'December 25, 1985', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(92, 9, 16, 'emailJam@gmail.com', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(93, 9, 5, 'Tarlac City, Capas', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(94, 9, 13, '40,000', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(95, 10, 1, 'Francis', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(96, 10, 2, 'Brands', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(97, 10, 7, '45', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(98, 10, 6, 'Male', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(99, 10, 15, 'June 5, 1981', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(100, 10, 16, 'emailfrant@gmail.com', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(101, 10, 5, 'Clark, Pampanga', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(102, 10, 13, '65,000', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(103, 11, 1, 'Janella', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(104, 11, 2, 'Panganiban', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(105, 11, 7, '23', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(106, 11, 6, 'Female', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(107, 11, 15, 'July 5, 1996', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(108, 11, 16, 'emailJanella@gmail.com', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(109, 11, 5, 'Manila', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(110, 11, 13, '24,000', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(111, 13, 3, 'Student-002', '2021-11-29 07:26:42', '2021-11-29 07:26:42'),
	(112, 13, 1, 'Dranid', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(113, 13, 2, 'Siano', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(114, 13, 8, 'Fourth Year', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(115, 13, 9, '4A', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(116, 13, 5, 'Tarlac City, Tarlac San Vicente', '2021-11-29 08:02:38', '2021-11-29 08:02:38'),
	(117, 13, 6, 'Male', '2021-11-29 08:04:07', '2021-11-29 08:04:07'),
	(118, 14, 3, 'Student-012', '2021-11-29 07:26:42', '2021-11-29 07:26:42'),
	(119, 14, 1, 'Vans', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(120, 14, 2, 'Cranes', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(121, 14, 8, 'Third Year', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(122, 14, 9, '3C', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(123, 14, 5, 'Tarlac City, Tarlac San Sebastian', '2021-11-29 08:02:38', '2021-11-29 08:02:38'),
	(124, 14, 6, 'Male', '2021-11-29 08:04:07', '2021-11-29 08:04:07'),
	(154, 16, 3, 'Student-006', '2021-11-29 07:26:42', '2021-11-29 07:26:42'),
	(155, 16, 1, 'Dranides', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(156, 16, 2, 'Sianosss', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(157, 16, 8, 'Second Year', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(158, 16, 9, '2A', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(159, 16, 5, 'Tarlac City, Tarlac San Paul', '2021-11-29 08:02:38', '2021-11-29 08:02:38'),
	(160, 16, 6, 'Male', '2021-11-29 08:04:07', '2021-11-29 08:04:07'),
	(161, 17, 3, 'Student-013', '2021-11-29 07:26:42', '2021-11-29 07:26:42'),
	(162, 17, 1, 'Vansked', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(163, 17, 2, 'Cryses', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(164, 17, 8, 'First Year', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(165, 17, 9, '2E', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(166, 17, 5, 'Tarlac City, Tarlac San Carlos', '2021-11-29 08:02:38', '2021-11-29 08:02:38'),
	(167, 17, 6, 'Male', '2021-11-29 08:04:07', '2021-11-29 08:04:07'),
	(168, 15, 3, 'Student-014', '2021-11-29 07:26:42', '2021-11-29 07:26:42'),
	(169, 15, 1, 'Clad', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(170, 15, 2, 'Crisis', '2021-11-29 07:28:06', '2021-11-29 07:28:06'),
	(171, 15, 8, 'Second Year', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(172, 15, 9, '2E', '2021-11-29 07:45:08', '2021-11-29 07:45:08'),
	(173, 15, 5, 'Tarlac City, Tarlac Macabulos', '2021-11-29 08:02:38', '2021-11-29 08:02:38'),
	(174, 15, 6, 'Male', '2021-11-29 08:04:07', '2021-11-29 08:04:07'),
	(175, 18, 1, 'Brenda', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(176, 18, 2, 'Browls', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(177, 18, 7, '35', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(178, 18, 6, 'Female', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(179, 18, 15, 'July 5, 1945', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(180, 18, 16, 'emailBrenda@gmail.com', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(181, 18, 5, 'Pangasinan, Dagupan', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(182, 18, 13, '48,000', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(183, 1, 9, 'Null', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(184, 8, 9, 'Null', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(185, 9, 9, 'Null', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(186, 10, 9, 'Null', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(187, 11, 9, 'Null', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(188, 19, 1, 'Socces', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(189, 19, 2, 'Cunars', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(190, 19, 5, 'Clark City, Pampanga', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(191, 19, 6, 'Male', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(192, 19, 7, '28', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(193, 19, 9, 'Null', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(194, 19, 13, '50,000', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(195, 19, 15, 'July 5, 1992', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(196, 19, 16, 'emailsocces@gmail.com', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(197, 20, 1, 'Alfredoses', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(198, 20, 2, 'Crawses', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(199, 20, 5, 'Tarlac City, Tibags', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(200, 20, 6, 'Male', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(201, 20, 7, '31', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(202, 20, 9, 'Null', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(203, 20, 13, '25,000', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(204, 20, 15, 'March 15, 1991', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(205, 20, 16, 'emailalfredo@gmail.com', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(206, 21, 1, 'Jamilles', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(207, 21, 2, 'Sandforder', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(208, 21, 5, 'Tarlac City, Capases', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(209, 21, 6, 'Male', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(210, 21, 7, '25', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(211, 21, 9, 'Null', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(212, 21, 13, '40,000', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(213, 21, 15, 'December 25, 1985', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(214, 21, 16, 'emailJamels@gmail.com', '2021-11-29 07:24:35', '2021-11-29 07:24:35'),
	(215, 22, 1, 'Francises', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(216, 22, 2, 'Brandses', '2021-11-29 07:22:24', '2021-11-29 07:22:24'),
	(217, 22, 5, 'Clark, Pampangas', '2021-11-29 07:25:06', '2021-11-29 07:25:06'),
	(218, 22, 6, 'Male', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(219, 22, 7, '45', '2021-11-29 07:24:17', '2021-11-29 07:24:17'),
	(220, 22, 9, 'Null', '2021-11-29 07:22:24', '2021-11-29 07:22:24');
/*!40000 ALTER TABLE `entities_details` ENABLE KEYS */;

-- Dumping structure for table db_sql_exam.entities_main
CREATE TABLE IF NOT EXISTS `entities_main` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_entities_main_id` int(11) NOT NULL,
  `type_id` varchar(100) NOT NULL,
  `school_entities_id` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_entities_main_id` (`parent_entities_main_id`),
  KEY `school_entities_id` (`school_entities_id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `entities_main_ibfk_1` FOREIGN KEY (`school_entities_id`) REFERENCES `school_entities` (`school_entities_id`),
  CONSTRAINT `entities_main_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `entities_types` (`entities_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table db_sql_exam.entities_main: ~22 rows (approximately)
/*!40000 ALTER TABLE `entities_main` DISABLE KEYS */;
INSERT IGNORE INTO `entities_main` (`id`, `parent_entities_main_id`, `type_id`, `school_entities_id`, `created`, `updated`) VALUES
	(8, 1, 'Sys-004', 'System-001', '2021-11-29 07:15:14', '2021-11-29 07:15:14'),
	(9, 3, 'SysStudent-004', 'System-001', '2021-11-29 07:25:47', '2021-11-29 07:25:47'),
	(10, 4, 'SysStudent-004', 'System-001', '2021-11-29 08:15:12', '2021-11-29 08:15:12'),
	(11, 5, 'SysStudent-004', 'System-001', '2021-11-29 08:16:27', '2021-11-29 08:16:27'),
	(12, 6, 'SysStudent-004', 'System-001', '2021-11-29 08:18:13', '2021-11-29 08:18:13'),
	(13, 7, 'SysStudent-004', 'System-001', '2021-11-29 08:18:13', '2021-11-29 08:18:13'),
	(16, 8, 'Sys-004', 'System-001', '2021-11-29 11:31:05', '2021-11-29 11:31:05'),
	(17, 9, 'Sys-004', 'System-001', '2021-11-29 11:34:42', '2021-11-29 11:34:42'),
	(18, 10, 'Sys-004', 'System-001', '2021-11-29 11:34:42', '2021-11-29 11:34:42'),
	(19, 11, 'Sys-004', 'System-001', '2021-11-29 11:34:42', '2021-11-29 11:34:42'),
	(20, 12, 'Sys-004', 'System-001', '2021-11-29 11:34:42', '2021-11-29 11:34:42'),
	(21, 13, 'SysStudent-004', 'CLSU', '2021-11-29 12:27:40', '2021-11-29 12:27:40'),
	(22, 14, 'SysStudent-004', 'CLSU', '2021-11-29 12:42:07', '2021-11-29 12:42:07'),
	(23, 15, 'SysStudent-004', 'CLSU', '2021-11-29 12:44:06', '2021-11-29 12:44:06'),
	(24, 16, 'SysStudent-004', 'CLSU', '2021-11-29 12:44:06', '2021-11-29 12:44:06'),
	(25, 17, 'SysStudent-004', 'CLSU', '2021-11-29 12:44:06', '2021-11-29 12:44:06'),
	(26, 18, 'Sys-004', 'CLSU', '2021-11-29 13:08:26', '2021-11-29 13:08:26'),
	(27, 19, 'Sys-004', 'CLSU', '2021-11-29 14:39:18', '2021-11-29 14:39:18'),
	(28, 20, 'Sys-004', 'CLSU', '2021-11-29 14:39:18', '2021-11-29 14:39:18'),
	(29, 21, 'Sys-004', 'CLSU', '2021-11-29 14:39:18', '2021-11-29 14:39:18'),
	(30, 22, 'Sys-004', 'CLSU', '2021-11-29 14:39:18', '2021-11-29 14:39:18'),
	(31, 23, 'Sys-004', 'CLSU', '2021-11-29 14:39:18', '2021-11-29 14:39:18');
/*!40000 ALTER TABLE `entities_main` ENABLE KEYS */;

-- Dumping structure for table db_sql_exam.entities_types
CREATE TABLE IF NOT EXISTS `entities_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_type_id` varchar(100) NOT NULL,
  `code` char(50) NOT NULL,
  `description` char(50) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_type_id` (`entities_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table db_sql_exam.entities_types: ~2 rows (approximately)
/*!40000 ALTER TABLE `entities_types` DISABLE KEYS */;
INSERT IGNORE INTO `entities_types` (`id`, `entities_type_id`, `code`, `description`, `created`, `updated`) VALUES
	(1, 'SysStudent-004', 'student', 'Student', '2021-11-29 04:59:27', '2021-11-29 04:59:27'),
	(2, 'Sys-004', 'teacher', 'Teacher', '2021-11-29 04:59:27', '2021-11-29 04:59:27');
/*!40000 ALTER TABLE `entities_types` ENABLE KEYS */;

-- Dumping structure for table db_sql_exam.school_entities
CREATE TABLE IF NOT EXISTS `school_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_entities_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `school_entities_id` (`school_entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table db_sql_exam.school_entities: ~5 rows (approximately)
/*!40000 ALTER TABLE `school_entities` DISABLE KEYS */;
INSERT IGNORE INTO `school_entities` (`id`, `school_entities_id`, `name`, `address`) VALUES
	(1, 'System-001', 'Angeles University Foundation ', 'Balibago, Angeles City'),
	(2, 'TSU001', 'Tarlac State University', 'Tarlac City'),
	(3, 'NEUST-001', 'Nueva Ecija University State Technology', 'Nueva Ecija, Cabanatuan'),
	(4, 'UST-001', 'University of Santo Thomas', 'Manila'),
	(5, 'CLSU', 'Central Luzon State University', 'University in Muñoz, Nueva Ecija');
/*!40000 ALTER TABLE `school_entities` ENABLE KEYS */;

-- Dumping structure for view db_sql_exam.view all
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view all` (
	`SchoolName` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`SchoolID` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`SchoolAddress` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`firstname` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Lastname` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Gender` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Section` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Types` CHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view db_sql_exam.vw_auf_students
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_auf_students` (
	`SchoolName` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`SchoolID` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`SchoolAddress` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`firstname` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Lastname` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`StudentAddress` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Gender` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`StudentSection` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view db_sql_exam.vw_auf_teachers
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_auf_teachers` (
	`SchoolName` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`SchoolID` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`SchoolAddress` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`firstname` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Lastname` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`StudentAddress` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Email` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Salary` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view db_sql_exam.view all
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view all`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `view all` AS select distinct `tbl1`.`name` AS `SchoolName`,`tbl1`.`school_entities_id` AS `SchoolID`,`tbl1`.`address` AS `SchoolAddress`,`tbl3`.`value` AS `firstname`,`tbl5`.`value` AS `Lastname`,`tbl20`.`value` AS `Gender`,`tbl22`.`value` AS `Section`,`tbl9`.`description` AS `Types` from ((((((((((((`school_entities` `tbl1` join `entities_main` `tbl2` on(`tbl1`.`school_entities_id` = 'System-001' or `tbl1`.`school_entities_id` = 'CLSU' and `tbl1`.`school_entities_id` = `tbl2`.`school_entities_id`)) join `entities_details` `tbl3` on(`tbl3`.`entities_main_id` = `tbl2`.`parent_entities_main_id`)) join `attributes_types` `tbl4` on(`tbl4`.`id` = `tbl3`.`attributes_types_id` and `tbl4`.`code` = 'fname')) join `entities_details` `tbl5` on(`tbl5`.`entities_main_id` = `tbl2`.`parent_entities_main_id`)) join `attributes_types` `tbl6` on(`tbl6`.`id` = `tbl5`.`attributes_types_id` and `tbl6`.`code` = 'lname')) join `entities_details` `tbl7` on(`tbl7`.`entities_main_id` = `tbl2`.`parent_entities_main_id`)) join `attributes_types` `tbl8` on(`tbl8`.`id` = `tbl7`.`attributes_types_id` and `tbl8`.`code` = 'address')) join `entities_details` `tbl20` on(`tbl20`.`entities_main_id` = `tbl2`.`parent_entities_main_id`)) join `attributes_types` `tbl21` on(`tbl21`.`id` = `tbl20`.`attributes_types_id` and `tbl21`.`code` = 'gender')) join `entities_details` `tbl22` on(`tbl22`.`entities_main_id` = `tbl2`.`parent_entities_main_id`)) join `attributes_types` `tbl23` on(`tbl23`.`id` = `tbl22`.`attributes_types_id` and `tbl23`.`code` = 'section')) join `entities_types` `tbl9` on(`tbl9`.`entities_type_id` = `tbl2`.`type_id` and `tbl1`.`school_entities_id` = `tbl2`.`school_entities_id`)) order by `tbl2`.`created`;

-- Dumping structure for view db_sql_exam.vw_auf_students
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_auf_students`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_auf_students` AS SELECT DISTINCT tbl1.name AS SchoolName, 
tbl1.school_entities_id AS SchoolID,
tbl1.address AS SchoolAddress, 
tbl3.value AS firstname, 
tbl5.value AS Lastname,
tbl7.value AS StudentAddress,
tbl9.value AS Gender,
tbl11.value AS StudentSection
FROM school_entities tbl1
INNER JOIN entities_main tbl2 ON tbl1.school_entities_id = 'System-001' AND tbl2.type_id = 'SysStudent-004'
INNER JOIN entities_details tbl3 ON tbl3.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl4 ON tbl4.id = tbl3.attributes_types_id AND tbl4.code = 'fname'
INNER JOIN entities_details tbl5 ON tbl5.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl6 ON tbl6.id = tbl5.attributes_types_id AND tbl6.code = 'lname'
INNER JOIN entities_details tbl7 ON tbl7.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl8 ON tbl8.id = tbl7.attributes_types_id AND tbl8.code = 'address'
INNER JOIN entities_details tbl9 ON tbl9.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl10 ON tbl10.id = tbl9.attributes_types_id AND tbl10.code = 'gender'
INNER JOIN entities_details tbl11 ON tbl11.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl12 ON tbl12.id = tbl11.attributes_types_id AND tbl12.code = 'section'
ORDER BY tbl2.created ASC ;

-- Dumping structure for view db_sql_exam.vw_auf_teachers
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_auf_teachers`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_auf_teachers` AS SELECT DISTINCT tbl1.name AS SchoolName, 
tbl1.school_entities_id AS SchoolID,
tbl1.address AS SchoolAddress, 
tbl3.value AS firstname, 
tbl5.value AS Lastname,
tbl7.value AS StudentAddress,
tbl9.value AS Email,
tbl11.value AS Salary
FROM school_entities tbl1
INNER JOIN entities_main tbl2 ON tbl1.school_entities_id = 'System-001' AND tbl2.type_id = 'Sys-004'
INNER JOIN entities_details tbl3 ON tbl3.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl4 ON tbl4.id = tbl3.attributes_types_id AND tbl4.code = 'fname'
INNER JOIN entities_details tbl5 ON tbl5.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl6 ON tbl6.id = tbl5.attributes_types_id AND tbl6.code = 'lname'
INNER JOIN entities_details tbl7 ON tbl7.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl8 ON tbl8.id = tbl7.attributes_types_id AND tbl8.code = 'address'
INNER JOIN entities_details tbl9 ON tbl9.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl10 ON tbl10.id = tbl9.attributes_types_id AND tbl10.code = 'email'
INNER JOIN entities_details tbl11 ON tbl11.entities_main_id = tbl2.parent_entities_main_id
INNER JOIN attributes_types tbl12 ON tbl12.id = tbl11.attributes_types_id AND tbl12.code = 'salary'
ORDER BY tbl2.created ASC ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
